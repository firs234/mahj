<?php
include 'index.php';
var_dump(checkGmail('cobrauw7w7wyeue7@gmail.com'));